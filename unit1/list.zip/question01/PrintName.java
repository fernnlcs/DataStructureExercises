package unit1.question01;

public class PrintName {
    
    public static void main(String[] args) {
        System.out.println("Fernando");
    }

}
